<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="3_doprocessingform.php" method="post">
            <input type="text" name="myname" />
            <input type="submit" />
        </form>
    </body>
</html>
