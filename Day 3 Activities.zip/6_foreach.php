<?php

$rainfall = array(728, 645, 675, 665, 818, 971,
    867, 881, 901, 701, 678, 652);

foreach ($rainfall as $key => $value) {
    echo "Key $key has value $value <br>";
}
?>
