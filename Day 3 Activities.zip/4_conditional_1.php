<?php
$score = 60;
if($score >= 50) {
    echo "You passed the exam";
}else{
    echo "You FAILED";
}
?>