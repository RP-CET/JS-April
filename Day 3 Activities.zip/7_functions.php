<?php
echo substr('republic', 1);
echo "<br>";
echo substr('republic', 1, 3);
echo "<br>";
echo substr('republic', 0, 4);
echo "<br>";
echo substr('republic', -1, 1);
echo "<br>";

echo strlen('republic');
echo "<br>";

echo strtolower('REPUBLIC');
echo "<br>";
ECHO strtoupper('Republic');
?>