<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="5_dodynamic_loop_3.php" method="post">
            <label for="idReps">Enter repetition</label>
            <input type="number" id="idReps" name="reps" />
            <br/><br/>
            Select chess to repeat:
            <input type="radio" name="chess" value="9818"/>&#9818;
            <input type="radio" name="chess" value="9819"/>&#9819;
            <input type="radio" name="chess" value="9820"/>&#9820;
            <input type="radio" name="chess" value="9822"/>&#9822;
            <br/><br/>
            <input type="submit" value="Go"/>
        </form>
    </body>
</html>
