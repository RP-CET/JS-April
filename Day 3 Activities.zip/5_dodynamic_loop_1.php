<?php
$reps = $_POST['reps'];

for($i=1; $i <= $reps; $i++){
    echo $i . "<br/>";
}
?>