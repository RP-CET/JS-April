<?php
$start = $_POST['start'];
$end = $_POST['end'];

for($i=$start; $i<=$end;$i++){
    echo $i . "<br/>";
}
?>