<?php
$reps = $_POST['reps'];
$chess = $_POST['chess'];

for($i=1; $i <= $reps; $i++){
    echo "&#" . $chess . ";";
}
?>