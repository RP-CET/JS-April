<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form method="post" action="9_doinsert.php">
            <input type="text" name="movieTitle" placeholder="Movie Title"/>
            <input type="text" name="movieDirector" placeholder="Movie Director"/>
            <input type="submit" value="Insert Movie"/>
        </form>
    </body>
</html>
