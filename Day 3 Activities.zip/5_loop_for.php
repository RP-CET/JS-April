<?php
//1 2 3 4 5 6 7 8 9 10
for ($i = 1; $i <= 10; $i++) {
    echo $i . " ";
}
?>
<br><br>
<?php
//-2 -1 0 1 2
for ($i = -2; $i <= 2; $i++) {
    echo $i . " ";
}
?>
<br><br>
<?php
//2 4 6 8 10 12
for ($i = 2; $i <= 12; $i += 2) {
    echo $i . " ";
}
?>
<br><br>
<?php
//12 8 4 0 -4
for ($i = 12; $i >= -4; $i -= 4) {
    echo $i . " ";
}
?>
<br><br>
<?php
for ($i = 1; $i <= 8; $i++) {
    if ($i % 2 == 0) {
        echo $i . " even<br>";
    }else{
        echo $i . " odd<br>";
    }
}
?>