<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="5_dodynamic_loop_1.php" method="post">
            <label for="idReps">Enter repetition</label>
            <input type="number" id="idReps" name="reps" />
            <br/><br/>
            <input type="submit" value="Go"/>
        </form>
    </body>
</html>
