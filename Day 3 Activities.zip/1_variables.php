<?php
$str1 = "Hello World!";
echo $str1;

$str2 = "What a nice day!";
echo "<br/>" . $str1 . " " . $str2;
?>
<br><br>
<?php
$num1 = 3;
$num2 = 5;
$result = $num1 * $num2;

echo "The total cost is $" . $result;
?>