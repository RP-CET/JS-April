<?php

$rainfall = array(728, 645, 675, 665, 818, 971,
    867, 881, 901, 701, 678, 652);
echo "<PRE>";
print_r($rainfall);
echo "</PRE>";
?>