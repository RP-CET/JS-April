<?php
$score = 90;
if($score >= 80) {
    echo "Your grade is <span style='color:green'><b>A</b></span>";
}elseif ($score >= 60) {
    echo "Your grade is <span style='color:orange'><b>B</b></span>";
}else{
    echo "Your grade is <span style='color:red'><b>F</b></span>";
}

?>