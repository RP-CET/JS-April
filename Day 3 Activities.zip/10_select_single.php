<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h2>Search for movie based on title</h2>
        <form name="frmSearch" method="post" action="10_doselect_single.php">
            <label for="idMovieTitle">Title :</label>
            <input id="idMovieTitle" type="text" name="movieTitle"/>
            <br/><br/>
            <input type="submit" value="Search"/><br/>
        </form>
    </body>
</html>
