<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="5_dodynamic_loop_2.php" method="post">
            <label for="idStart">Enter start</label>
            <input type="number" id="idStart" name="start" />
            <br/><br/>
            <label for="idEnd">Enter end</label>
            <input type="number" id="idEnd" name="end" />
            <br/><br/>
            <input type="submit" value="Go"/>
        </form>
    </body>
</html>
