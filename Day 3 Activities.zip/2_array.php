<?php

$fruitsArr = array("apple", "orange", "pineapple");

echo $fruitsArr[2];
?>