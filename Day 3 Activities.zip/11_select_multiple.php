<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "day3";

// open connection
$conn = mysqli_connect($host, $user, $pass, $db);

if(!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
// build sql query
$sql = "SELECT * FROM movies";
// execute SQL query
$result = mysqli_query($conn, $sql);

$message = "";
if(mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_array($result)){
        $message .= "id: " . $row['id'] . "<br> - Title: " . $row['title']
            ."<br> <i>directed by</i> " . $row['director']. "<br><br>";
    }
} else{
    $message .= "0 results";
}
mysqli_close($conn);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        echo $message;
        ?>
    </body>
</html>
