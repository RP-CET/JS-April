<?php // 1 2 3 4 5 6 7 8 9 10
$i = 1;
while($i <= 10){
    echo $i . " ";
    $i++;
}
?>
<br><br>
<?php // -2 -1 0 1 2 
$i = -2;
while($i <= 2){
    echo $i . " ";
    $i++;
}
?>
<br><br>
<?php // 2 4 6 8 10 12
$i = 2;
while($i <= 12){
    echo $i . " ";
    $i+=2;
}
?>
<br><br>
<?php // 12 8 4 0 -4
$i = 12;
while($i >= -4){
    echo $i . " ";
    $i-=4;
}
?>
<br><br>
<?php 
$i = 1;
while($i <= 10){
    echo $i . " squared is " . $i*$i . "<br>";
    $i++;
}
?>