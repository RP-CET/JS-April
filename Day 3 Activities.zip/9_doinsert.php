<?php
$theTitle = $_POST['movieTitle'];
$theDirector = $_POST['movieDirector'];

$host = "localhost";
$user = "root";
$pass = "";
$db = "day3";

// open connection
$conn = mysqli_connect($host, $user, $pass, $db);

if(!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// build sql query
$sql = "INSERT INTO movies (director, title) VALUES ('$theDirector','$theTitle')";

//execute query and process the result
if(mysqli_query($conn, $sql)) {
    $message = "New record created successfully";
}else{
    $message = "Error: " . $sql ."<br>" . mysqli_error($conn);
}

//close connection
mysqli_close($conn);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        echo $message;
        ?>
    </body>
</html>
