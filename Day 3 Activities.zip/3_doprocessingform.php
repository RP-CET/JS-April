<?php
$name = $_POST['myname'];
echo "My name is $name";
?>